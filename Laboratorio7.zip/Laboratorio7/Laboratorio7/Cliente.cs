﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio7
{
    class Cliente
    {
        private string nombre;
        private int monto;
        
        public Cliente(string nom)
        {
            nombre = nom;
            monto = 0;
    
        }

        public void Depoisitar(int m)
        {
            monto = monto + m;

        }

        public void Extraer (int m)
        { monto = monto - m; }

        public int RetornarMonto()
        { return monto; }

    public void Imprimir()
    { Console.WriteLine(nombre + "Tiene depositado la suma de " + monto); }
    }
}
